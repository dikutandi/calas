<style type="text/css">
    .form-horizontal .control-label {
        text-align: left;
        margin-bottom: 0;
        padding-top: 7px;
    }
</style>
<?php 
    $action = isset($edited_project) ? '/project/edit' : '/project';
 ?>
<div class="panel panel-default">
    <div class="panel-heading">Form Project E-Commerce</div>

    <div class="panel-body">
        <form class="form-horizontal" role="form" method="POST" action="<?php echo e(url($action)); ?>" enctype=multipart/form-data style="text-align: left;">
            <?php echo e(csrf_field()); ?>


            <div class="form-group<?php echo e($errors->has('project_name') ? ' has-error' : ''); ?>">
                <label for="name" class="col-md-3 control-label">Nama Project</label>

                <div class="col-md-8">
                    <?php echo e(Form::text('project_name', isset($calas->project_name) ? $calas->project_name : old('project_name'), ['class'=> 'form-control', 'placeholder' => 'Nama Project (cth: Marketplace Seperti Bukalapak.com)'])); ?>


                    <?php if($errors->has('project_name')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('project_name')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
            </div>

            <div class="form-group<?php echo e($errors->has('project_desc') ? ' has-error' : ''); ?>">
                <label for="name" class="col-md-3 control-label">Keterangan Project</label>

                <div class="col-md-8">
                    <?php echo e(Form::textarea('project_desc',  isset($calas->project_desc) ? $calas->project_desc : old('project_desc'), ['placeholder' => 'Jelaskan Secara Singkat Tentang Project Anda', 'class' => 'form-control', 'rows' => '5'])); ?>


                    <?php if($errors->has('project_desc')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('project_desc')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
            </div>

            <div class="form-group<?php echo e($errors->has('project_ppt') ? ' has-error' : ''); ?>">
                <label for="name" class="col-md-3 control-label">Upload Presentasi</label>

                <div class="col-md-8">
                    <span class="btn btn-success fileinput-button">
                        <i class="glyphicon glyphicon-plus"></i>
                        <span>Pilih File PPT...</span>
                        <!-- The file input field used as target for the file upload widget -->
                        <input id="fileupload" type="file" name="project_ppt" >
                    </span>

                    <span class="help-block" style="color: #a94442">
                        <?php echo e(isset($edited_project) ? 'Tidak perlu pilih CV Baru jika tidak ada perubahan. ' : ''); ?>

                        Format diterima hanya ..ppt/.pptx
                    </span>

                    <?php if($errors->has('project_ppt')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('project_ppt')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
            </div>

            <div class="form-group">
                <div class="col-md-6 col-md-offset-4">
                    <button type="submit" class="btn btn-primary">
                        <?php echo e(isset($edited_project) ? 'Update Project!' : 'Simpan Project!'); ?>

                    </button>
                </div>
            </div>
        </form>

    </div>
</div>
