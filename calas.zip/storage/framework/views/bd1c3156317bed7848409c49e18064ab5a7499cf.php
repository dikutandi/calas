<style type="text/css">
    .form-horizontal .control-label {
        text-align: left;
        margin-bottom: 0;
        padding-top: 7px;
    }
</style>
<?php 
    $action = isset($edited) ? '/profile/edit' : '/calas';
 ?>

<div class="panel panel-default">
    <div class="panel-heading">Form Calon Asisten</div>

    <div class="panel-body">
        <form class="form-horizontal" role="form" method="POST" action="<?php echo e(url($action)); ?>" enctype=multipart/form-data style="text-align: left;">
            <?php echo e(csrf_field()); ?>


            <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                <label for="name" class="col-md-2 control-label">Nama</label>

                <div class="col-md-8">
                    <input id="name" type="text" class="form-control" name="name" value="<?php echo e($user->name); ?>" readonly>

                    <?php if($errors->has('name')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('name')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
            </div>

            <div class="form-group<?php echo e($errors->has('kelas') || $errors->has('npm') ? ' has-error' : ''); ?>">
                <label for="kelas" class="col-md-2 control-label">Kelas</label>

                <div class="col-md-3">
                    <?php echo e(Form::text('kelas', isset($calas->kelas) ? $calas->kelas : old('kelas'), ['class'=> 'form-control', 'placeholder' => 'Kelas Anda'])); ?>


                    <?php if($errors->has('kelas')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('kelas')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>

                <div class="col-md-5">
                    <label class="col-md-4 control-label" for="npm" >
                        NPM
                    </label>
                    <div class="col-md-8">
                        <?php echo e(Form::text('npm', isset($calas->npm) ? $calas->npm : old('npm'), ['class'=> 'form-control', 'placeholder' => 'Masukan Npm Anda'])); ?>


                        <?php if($errors->has('npm')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('npm')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <div class="form-group<?php echo e($errors->has('ipk_lokal') || $errors->has('ipk_utama') ? ' has-error' : ''); ?>">
                <label for="kelas" class="col-md-2 control-label">IPK Utama</label>

                <div class="col-md-3">
                    <?php echo e(Form::text('ipk_utama', isset($calas->ipk_utama) ? $calas->ipk_utama : old('ipk_utama'), ['class'=> 'form-control', 'placeholder' => 'IPK Utama'])); ?>


                    <?php if($errors->has('ipk_utama')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('ipk_utama')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>

                <div class="col-md-5">
                    <label class="col-md-4 control-label" for="ipk_lokal" >
                        IPK Lokal
                    </label>
                    <div class="col-md-8">
                        <?php echo e(Form::text('ipk_lokal', isset($calas->ipk_lokal) ? $calas->ipk_lokal : old('ipk_lokal'), ['class'=> 'form-control', 'placeholder' => 'IPK Lokal'])); ?>


                        <?php if($errors->has('ipk_lokal')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('ipk_lokal')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- <div class="form-group<?php echo e($errors->has('lab_minat') ? ' has-error' : ''); ?>">
                <label for="name" class="col-md-2 control-label">Lab-Minat</label>

                <div class="col-md-5">
                    Form::select('lab_minat', $lab_minat, isset($calas->lab_minat) ? $calas->lab_minat : old('lab_minat') , ['class'=> 'form-control', 'placeholder' => 'Pilih salah satu'])

                    <?php if($errors->has('lab_minat')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('lab_minat')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
            </div> -->

            <div class="form-group<?php echo e($errors->has('contact') ? ' has-error' : ''); ?>">
                <label for="name" class="col-md-2 control-label">No HP</label>

                <div class="col-md-5">
                    <?php echo e(Form::text('contact', isset($calas->contact) ? $calas->contact : old('contact'), ['class'=> 'form-control', 'placeholder' => 'No HP'])); ?>


                    <?php if($errors->has('contact')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('contact')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
            </div>

            <div class="form-group<?php echo e($errors->has('alamat') ? ' has-error' : ''); ?>">
                <label for="name" class="col-md-2 control-label">Alamat</label>

                <div class="col-md-8">
                    <?php echo e(Form::textarea('alamat',  isset($calas->alamat) ? $calas->alamat : old('alamat'), ['placeholder' => 'Alamat Tempat Tinggal Saat Ini', 'class' => 'form-control', 'rows' => '5'])); ?>


                    <?php if($errors->has('alamat')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('alamat')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
            </div>

            <div class="form-group<?php echo e($errors->has('cv') ? ' has-error' : ''); ?>">
                <label for="name" class="col-md-2 control-label">Upload CV</label>

                <div class="col-md-8">
                    <input type="hidden" name="cv" >
                    <span class="btn btn-success fileinput-button">
                        <i class="glyphicon glyphicon-plus"></i>
                        <span><?php echo e(isset($edited) ? 'Select New CV...' : 'Select file...'); ?></span>
                        <!-- The file input field used as target for the file upload widget -->
                        <input id="fileupload" type="file" name="cv" value="<?php echo e(old('cv')); ?>">
                    </span>


                    <?php if($errors->has('cv')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('cv')); ?></strong>
                        </span>
                    <?php endif; ?>
                    <span class="help-block" style="color: blue"><?php echo e(isset($edited) ? 'Tidak perlu pilih CV Baru jika tidak ada perubahan' : ''); ?>. Format diterima hanya .pdf Contoh file yang diupload bisa dilihat dilink <a target="_BLANK" href="<?php echo e(url('cv.pdf')); ?>">berikut <?php echo e(url('cv.pdf')); ?></span>

                </div>
            </div>

            <div class="form-group">
                <div class="col-md-6 col-md-offset-4">
                    <button type="submit" class="btn btn-primary">
                        <?php echo e(isset($edited) ? 'Update Profile' : 'Daftar Asisten!'); ?>


                    </button>
                </div>
            </div>
        </form>

    </div>
</div>
