# calas
pendaftaran online calon asisten lab created with Laravel 5.3

Laravel 5 Docs <a href="https://laravel.com/docs/5.3"> Here </a>

After clone this repo do 

1. Create .env (here the example)
APP_ENV=local
APP_KEY=base64:1sN6MQCgnqgtWS7TJrqU0dVGYdXVZvqH3JEc+4RMrq0=
APP_DEBUG=true
APP_LOG_LEVEL=debug
APP_URL=http://localhost

DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=calas
DB_USERNAME=root
DB_PASSWORD=


2. Do "Composer Install" in the terminal

3. Do "php artisan migrate --seed

