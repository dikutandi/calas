<?php
return [
    'tgl_penting' => [
        ['19 - 31 Desember 2016', 'Pendaftaran Calon Asisten Lepkom', '2016-12-31'],
        ['01 - 03 Januari 2017', 'On Desk Selection', '2017-01-03'],
        ['04 - 06 Januari 2017', 'Persentasi dan Wawancara', '2017-01-06'],
        ['09 Januari 2017', 'Pengumuman Hasil Wawancara', '2017-01-09'],
        ['To Be Confirmed', 'Wawancara Terakhir dengan Ketua Lepkom', '2017-02-03'],
    ],
];
